# Control Agent chat

A 30-minute, device-local role-play chat with challenges and an optional AI model connection.

## Run locally

1. Install Node.js 20 or later.
2. Run `npm install` and then `npm run dev`.
3. Open `http://localhost:3000`.

The chat works immediately with short scripted replies. For open-ended AI replies, set `OPENAI_API_KEY` on the server (copy `.env.example` to `.env.local` and fill in the value). Keep this key out of GitHub. `OPENAI_MODEL` can override the default model.

## Deploy to Vercel

Push these project files to the root of your GitHub repository, then import that repository in Vercel. Set `OPENAI_API_KEY` in the Vercel project's Environment Variables to enable open-ended AI replies, then redeploy. If the repository currently contains only empty `app` and `lib` folders, upload this archive's contents, not the archive itself. The application is intentionally usable without a key, but replies will follow scripted patterns.

Sessions and chat history are stored in this browser's local storage. Clearing site data clears the session. There are no email or social account connections, and the app cannot run in the background or change account settings.
