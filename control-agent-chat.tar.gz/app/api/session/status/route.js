export async function GET(){return Response.json({ok:true,name:'30 Minute Agent Test'})}
